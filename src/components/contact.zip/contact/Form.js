import React from 'react'

const Form = () => {
  return (
    <>
        <form action="">
            <label htmlFor="" className='form-label'>Enter Name</label>
            <input type="text" className='form-control' />
            <br /><br />
            <label htmlFor="" className='form-label'>Enter Email</label>
            <input type="email" className='form-control'  />
            <br /><br />
            <label htmlFor="" className='form-label'>Enter Phone</label>
            <input type="number" className='form-control' />
            <br /><br />
            <input className='btn btn-success' type="submit" />
        </form>
    </>
  )
}

export default Form