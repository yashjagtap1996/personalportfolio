import React from 'react'

const Info = () => {
  return (
    <>
        <h1>Lorem, ipsum dolor.</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis quia quam dignissimos esse ratione? Explicabo, neque eos natus nemo debitis ad commodi molestias labore vel.</p>
        <h4>Living In</h4>
        <p>Lorem, ipsum dolor.</p>
        <h4>Call</h4>
        <p>+91-1487557866</p>
        
    </>
  )
}

export default Info